package external1

type Customer struct {
	Name string
	Age  int
}
