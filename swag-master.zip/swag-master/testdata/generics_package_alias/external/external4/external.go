package external4

type Customer struct {
	Name string
	Age  int
}
