package main

import _ "golang.org/x/tools/go/loader" // it inside contains invalid package files
func main()                             {}
